There are 4 files icluded in the zip file besides the ReadMe file.  Below are descriptions of each file:

CSV - The tabular data for the dataset and with a geography identifier that can be used to join to the geospatial shapefile.
ZIP - The shapefile of the data with a geography identifier the data table can be joined to.
XML - The metadata record
PDF (Data Description) - An overview of the dataset and methods used to create it.
PDF (Data Dictionary) - A file that gives a text description of the data contained in each column of the dataset, including the geography identifiers.

For questions or more information, please contact Jeffery Adkins (jeffery.adkins@noaa.gov)